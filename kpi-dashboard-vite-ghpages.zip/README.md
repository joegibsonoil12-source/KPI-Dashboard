# KPI Dashboard — Auto-build to GitHub Pages

Edit React here, push to GitHub, and your site updates automatically.

## Local dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## How Pages deploy works
- This repo contains a GitHub Actions workflow (`.github/workflows/deploy.yml`).
- On every push to `main`, it builds the Vite app and publishes `dist/` to GitHub Pages.
- The Vite `base` path is set automatically from your repo name, so the site works at:
  `https://<your-username>.github.io/<repo>/`

## No local Node? No problem
You can skip local builds. Just upload these files to GitHub.
The workflow builds for you in the cloud.
